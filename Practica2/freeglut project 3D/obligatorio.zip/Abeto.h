#ifndef Abeto_H_
#define Abeto_H_

#include "ObjetoCompuesto.h"
#include "Tronco.h"

class Abeto : public ObjetoCompuesto {

	/*protected:
		Tronco* _tronco;
		CopaCono* _copaCono; */


	public:
		Abeto();
		~Abeto();
		//void dibuja();


};

#endif
