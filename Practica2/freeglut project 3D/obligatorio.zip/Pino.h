#ifndef Pino_H_
#define Pino_H_

#include "Tronco.h"

#include "ObjetoCompuesto.h"

class Pino: public ObjetoCompuesto{

	protected:


	public:
		Pino();
		~Pino();

};

#endif