#ifndef Alamo_H_
#define Alamo_H_

#include "Tronco.h"
#include "ObjetoCompuesto.h"

class Alamo : public ObjetoCompuesto{

	protected:

	public:
		Alamo();
		~Alamo();


};

#endif


