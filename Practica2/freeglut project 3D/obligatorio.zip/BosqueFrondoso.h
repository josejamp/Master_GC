#ifndef BosqueFrondoso_H_
#define BosqueFrondoso_H_


#include "ObjetoCompuesto.h"
class BosqueFrondoso :
	public ObjetoCompuesto
{

protected:
	GLint _ancho;
	GLint _largo;

	ObjetoCompuesto* dameArbol();
	bool ponArbol();

public:
	BosqueFrondoso(GLint ancho, GLint largo);
	~BosqueFrondoso();
};

#endif